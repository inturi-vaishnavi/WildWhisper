---
name: Bio-Acoustic Field Apparatus
colors:
  surface: '#0d1510'
  surface-dim: '#0d1510'
  surface-bright: '#333b35'
  surface-container-lowest: '#08100b'
  surface-container-low: '#151d18'
  surface-container: '#19211c'
  surface-container-high: '#242c26'
  surface-container-highest: '#2e3731'
  on-surface: '#dce5dc'
  on-surface-variant: '#c1c8c0'
  inverse-surface: '#dce5dc'
  inverse-on-surface: '#2a322d'
  outline: '#8b938b'
  outline-variant: '#414942'
  surface-tint: '#a5d1ae'
  primary: '#a5d1ae'
  on-primary: '#0f381f'
  primary-container: '#4b7356'
  on-primary-container: '#caf6d2'
  inverse-primary: '#3f674b'
  secondary: '#b6cdaa'
  on-secondary: '#22351c'
  secondary-container: '#384c31'
  on-secondary-container: '#a5bc9a'
  tertiary: '#ffb785'
  on-tertiary: '#502500'
  tertiary-container: '#9f581f'
  on-tertiary-container: '#ffe7d9'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c1edc9'
  primary-fixed-dim: '#a5d1ae'
  on-primary-fixed: '#00210e'
  on-primary-fixed-variant: '#284f34'
  secondary-fixed: '#d2eac5'
  secondary-fixed-dim: '#b6cdaa'
  on-secondary-fixed: '#0e2009'
  on-secondary-fixed-variant: '#384c31'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb785'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#713700'
  background: '#0d1510'
  on-background: '#dce5dc'
  surface-variant: '#2e3731'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: 4rem
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 2rem
    fontWeight: '500'
    lineHeight: 2.5rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Space Grotesk
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Space Grotesk
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.05em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1.25rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The visual identity operates at the intersection of high-spec bio-acoustic field equipment and an avant-garde natural history monograph. Designed for low-light canopy immersion, tactile nocturnal observation, and hands-free environmental telemetry, the interface treats the screen as an illuminated scientific viewport. It balances the literary authority of deep botanical study with the utilitarian precision of field-recorded sonograms and local neural inference.

The aesthetic fuses deep canopy dark-mode surfaces with high-contrast typography: dramatic, editorial serif displays evoke archival field folios, while monoline, geometric grotesque letterforms anchor high-density telemetry, sensory readouts, and acoustic spectrograms. Interfaces prioritize rapid legibility in shifting outdoor ambient conditions, tactile micro-affordances for single-handed or gloved field interactions, and an austere, reverent presentation of the natural world.

## Colors

The palette is rooted in the deep darkness of old-growth understories, rejecting harsh synthetic blacks in favor of chromatic forest depths. 

- **Primary (`#4B7356`)**: Subdued moss green; acts as the primary operational hue, driving dynamic wave forms, signal lock indicators, and calibrated control states.
- **Secondary (`#A2B997`)**: Pale lichen; serves as the high-legibility telemetry partner, used for taxonomic rank indicators, acoustic frequency markers, and active metadata.
- **Tertiary (`#C97A3E`)**: Earth terracotta and amber; deployed strictly for biological alerts, venom/hazard classification warnings, tracking battery telemetry thresholds, and safety flags.
- **Neutral (`#121A15`)**: Deep night-canopy tone; provides the optical foundation. Surfaces scale upward from this base through translucent layers of green-tinted obsidian.
- **Functional Luminescence**: Vital biological signals and live listening triggers deploy a calibrated emerald flash (`#22C55E`) dialed back into optical harmony with forest obsidian backgrounds.

## Typography

The typographic tension between Playfair Display and Space Grotesk mirrors the balance between natural specimen curation and real-time sensory computation.

- **Playfair Display**: Reserved for specimen names, Latin binomials, field chapter openings, and major audio encounter headers. Its italic variants are mandatory when rendering formal biological nomenclature (e.g., *Strix aluco*).
- **Space Grotesk**: Dictates all navigational UI, spectrogram axis values, neural confidence intervals, status flags, and descriptive narratives. In labels, apply uppercase with explicit tracking to emulate laser-etched field instruments. Maintain tabular figures for real-time acoustic readouts (dB, kHz, latitude/longitude) to avoid layout jitter during active signal acquisition.

## Layout & Spacing

The layout is built upon an adaptive 12-column structural grid (4-column on mobile, 8-column on tablet) designed to preserve generous visual rest zones while accommodating dense analytical sidebars.

- **Rhythm & Touch Buffers**: Outdoor ergonomics require exaggerated separation between interactive touch targets. Touch areas must never drop below 48x48 points, supported by `space-md` gaps even when visual elements occupy smaller footprints.
- **Canopy Framing**: Content containers use the outer `margin` to maintain distance from physical display borders, accommodating ruggedized protective device cases and single-thumb reach zones during field walking.
- **Asymmetric Composition**: Balance dense analytical telemetry cards against airy, unconstrained specimen cards to preserve the editorial magazine quality across wide screen formats.

## Elevation & Depth

Visual hierarchy is constructed through luminous containment and optical atmospheric depth rather than traditional drop shadows:

- **Surface Layering**: The primary viewport is `#121A15`. Raised panels utilize stepped tonal shifts (`#18231D`, `#1F2D25`) paired with sub-pixel surface illumination.
- **Ghost Boundary Lines**: Layers are defined by hairline borders (`1px` solid `rgba(162, 185, 151, 0.12)`). High-priority listening modules increase border opacity to `0.28`.
- **Acoustic Luminescence**: Active audio capture and confirmed taxonomic detections emit a directional, diffuse back-glow (`0px 8px 32px rgba(75, 115, 86, 0.25)`), creating the effect of illuminated instrument displays observed in complete forest darkness.
- **Backdrop Blurs**: Floating toolbars and hands-free overlays use heavy backdrop filtering (`blur(16px)`) with an 85% opacity canopy fill to keep live camera or spectrogram feeds subtly visible behind interface controls.

## Shapes

The interface balances organic, river-worn contours with mechanical precision. Utilizing roundedness factor `2`:

- **Primary Surfaces & Cards**: `rounded-lg` (1rem / 16px) provides structural calm, rounding hard data matrices into approachable, human-scaled field notebooks.
- **Micro UI & Indicators**: Badges, status markers, and operational controls use `0.5rem` (8px) corners, keeping technical metrics sharp and immediate.
- **Pill Exceptions**: Hands-free toggle switches, voice-state indicators, and persistent status meters adopt full capsule geometry (`9999px`) to visually signal tactile, toggle-ready physical controls.

## Components

### Buttons & Action Controls
- **Primary Field Trigger**: High-contrast, tactile, moss-tinted surface (`#4B7356`) with light contrasting text (`#F9F8F3`), `rounded-lg` silhouette, minimum height of `56px` for outdoor use. Subtle inner border highlight (`1px inset rgba(255,255,255,0.15)`).
- **Secondary Ghost Action**: Dark canopy background with a crisp border (`1px solid rgba(162, 185, 151, 0.3)`), shifting to a muted sage fill upon press.

### Chips & Badges
- **Acoustic State Chip**: Capsule pill containing a dynamic recording indicator (`#22C55E` pulsating dot) flanked by tracked uppercase typography in Space Grotesk.
- **Taxonomic Pill**: Monospaced-style label chip (`0.5rem` radius) displaying family, genus, and confidence scores (`98.4% MATCH`).

### Cards & Specimen Folios
- **Specimen Sightings**: Structured observation cards featuring deep green-tinted backgrounds (`#18231D`), hairline outer outlines, large Playfair Display specimen names, and high-density Space Grotesk bio-telemetry sidebars.
- **Spectrogram Viewer**: Oscilloscope-inspired dark canvas with overlaid frequency lines, decibel indices, and a floating scrubbing target.

### Inputs & Telemetry Fields
- **Voice-First Input Module**: Hands-free visualizer with a centrally nested listening orb that flexes and radiates based on ambient decibel intake.
- **Manual Log Input**: Flat, dark-recessed input field bordered by low-opacity moss borders, shifting to sharp `#A2B997` outlines on focus. Text remains high-contrast crisp white.

### Lists & Observation Logs
- **Log Item**: Borderless stacked entries separated by single-pixel horizontal dividers (`rgba(162, 185, 151, 0.08)`). Left column isolates timestamp and audio frequency; right column holds specimen classification and editorial narrative.